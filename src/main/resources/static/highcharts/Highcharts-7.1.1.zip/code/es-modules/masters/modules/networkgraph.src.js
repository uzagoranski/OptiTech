/**
 * @license  @product.name@ JS v@product.version@ (@product.date@)
 * @module highcharts/modules/networkgraph
 * @requires highcharts
 *
 * Force directed graph module
 *
 * (c) 2010-2019 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/networkgraph/networkgraph.src.js';
